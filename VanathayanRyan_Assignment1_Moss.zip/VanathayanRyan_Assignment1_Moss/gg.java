import java.lang.ArithmeticException;
import java.util.ArrayList;
public class gg extends PasswordCheckerUtility{

	public static void main(String[] args) throws ArithmeticException, NoUpperAlphaException, NoSpecialCharacterException, NoLowerAlphaException, NoDigitException, LengthException, InvalidSequenceException{
		// TODO Auto-generated method stub
		
		ArrayList<String> passwords = new ArrayList<String>();
		passwords.add("334455BB#");
		passwords.add("george2ZZZ#");
		passwords.add("4Sale#");
		passwords.add("bertha22");
		passwords.add("august30");
		passwords.add("a2cDe");
		passwords.add("ApplesxxYYzz#");
		passwords.add("aa11bb");
		passwords.add("pilotProject");
		passwords.add("myPassword");
		passwords.add("myPassword2");
		passwords.add("AAAbb@123");
		
		ArrayList<String> invalidPasswords = getInvalidPasswords​(passwords);
		
		for(String i : invalidPasswords) {
			System.out.println(i);
		}
	}

}
